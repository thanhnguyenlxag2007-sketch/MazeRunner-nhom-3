# Maze Runner raylib C++

Project này có 3 phiên bản để thể hiện quá trình cải tiến theo vibe coding:

- `main.cpp`: bản gốc, có mê cung, người chơi, quái đuổi theo, cửa thoát.
- `main_2.cpp`: dựa trên bản gốc, đổi 2 cục xanh/đỏ thành nhân vật pixel đơn giản và thêm 5 vật phẩm để nhặt.
- `main_3.cpp`: bản hoàn chỉnh, tổng hợp bản gốc + bản 2, thêm random màn chơi mỗi lần restart.

## Điều khiển

- `WASD` hoặc phím mũi tên: di chuyển
- `R`: restart

## Cách compile bằng MSYS2 UCRT64

Compile bản gốc:

```bash
g++ main.cpp -o maze_runner.exe -lraylib -lopengl32 -lgdi32 -lwinmm
./maze_runner.exe
```

Compile bản 2:

```bash
g++ main_2.cpp -o maze_runner_v2.exe -lraylib -lopengl32 -lgdi32 -lwinmm
./maze_runner_v2.exe
```

Compile bản 3:

```bash
g++ main_3.cpp -o maze_runner_v3.exe -lraylib -lopengl32 -lgdi32 -lwinmm
./maze_runner_v3.exe
```
## Yêu cầu

- C++
- Raylib
- MSYS2 UCRT64 hoặc môi trường C++ có cài raylib
// PHIEN BAN 3 - San pham hoan chinh co MENU CHINH
// Tong hop main.cpp va main_2.cpp.
// Them: random man choi moi lan bam R restart + giu nhan vat pixel + 5 vat pham.
// Nang cap: menu chinh cho phep chon mau nhan vat: vang, tim, hong, den.

#include "raylib.h"
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

const int ROWS = 21;
const int COLS = 31;
const int TILE = 28;
const int UI_HEIGHT = 70;
const int SCREEN_W = COLS * TILE;
const int SCREEN_H = ROWS * TILE + UI_HEIGHT;

struct Enemy {
    int r, c;
    float timer;
};

struct Item {
    int r, c;
    bool collected;
};

vector<vector<string>> mazeList = {
    {
        "###############################",
        "#S#.........#.................#",
        "#.#.#######.#.#############.#.#",
        "#.#.....#...#.....#.......#.#.#",
        "#.#####.#.#######.#.#####.#.#.#",
        "#.....#.#.......#.#.#...#.#.#.#",
        "#####.#.#######.#.#.#.#.#.#.#.#",
        "#.....#.....#...#...#.#...#...#",
        "#.#########.#.#######.#######.#",
        "#.........#.#.....#.........#.#",
        "#.#######.#.#####.#.#######.#.#",
        "#.#.....#.#.....#.#.#.....#.#.#",
        "#.#.###.#.#####.#.#.#.###.#.#.#",
        "#.#...#.#.......#.#...#...#...#",
        "#.###.#.#########.#####.#####.#",
        "#.....#.........#.....#.....#.#",
        "#.#############.#.###.#####.#.#",
        "#...............#...#.......#.#",
        "#.#################.#########.#",
        "#.........................E...#",
        "###############################"
    },
    {
        "###############################",
        "#S............#...............#",
        "#####.#######.#.###########.#.#",
        "#.....#.....#.#.....#.......#.#",
        "#.#####.###.#.#####.#.#######.#",
        "#.......#...#.....#.#.........#",
        "#.#######.#######.#.#########.#",
        "#.#.....#.......#.#.....#.....#",
        "#.#.###.#######.#.#####.#.###.#",
        "#...#.#.......#.#.......#...#.#",
        "###.#.#######.#.###########.#.#",
        "#...#.......#.#.............#.#",
        "#.#########.#.###############.#",
        "#.........#.#.................#",
        "#.#######.#.#################.#",
        "#.#.....#.#.................#.#",
        "#.#.###.#.#################.#.#",
        "#...#...#.................#...#",
        "#.###.###################.###.#",
        "#.........................E...#",
        "###############################"
    },
    {
        "###############################",
        "#S......#.....................#",
        "#.#######.###################.#",
        "#.......#.........#...........#",
        "#######.#########.#.#########.#",
        "#.....#.........#.#.........#.#",
        "#.#.###########.#.#########.#.#",
        "#.#.............#.....#.....#.#",
        "#.#################.#.#.#####.#",
        "#.........#.........#.#.......#",
        "#.#######.#.#########.#######.#",
        "#.#.....#.#.......#.........#.#",
        "#.#.###.#.#######.#.#######.#.#",
        "#...#...#.......#.#.....#...#.#",
        "#.###.#########.#.#####.#.###.#",
        "#.....#.........#.....#.#.....#",
        "#####.#.#############.#.#####.#",
        "#.....#...............#.......#",
        "#.###########################.#",
        "#.........................E...#",
        "###############################"
    }
};

bool IsWall(const vector<string>& maze, int r, int c) {
    if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return true;
    return maze[r][c] == '#';
}

bool CanMove(const vector<string>& maze, int r, int c) {
    return !IsWall(maze, r, c);
}

vector<pair<int,int>> FindPath(const vector<string>& maze, int sr, int sc, int tr, int tc) {
    vector<vector<int>> dist(ROWS, vector<int>(COLS, -1));
    vector<vector<pair<int,int>>> parent(ROWS, vector<pair<int,int>>(COLS, {-1, -1}));
    queue<pair<int,int>> q;
    q.push({sr, sc});
    dist[sr][sc] = 0;

    int dr[4] = {-1, 1, 0, 0};
    int dc[4] = {0, 0, -1, 1};

    while (!q.empty()) {
        auto [r, c] = q.front();
        q.pop();

        if (r == tr && c == tc) break;

        for (int i = 0; i < 4; i++) {
            int nr = r + dr[i];
            int nc = c + dc[i];
            if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && dist[nr][nc] == -1 && CanMove(maze, nr, nc)) {
                dist[nr][nc] = dist[r][c] + 1;
                parent[nr][nc] = {r, c};
                q.push({nr, nc});
            }
        }
    }

    vector<pair<int,int>> path;
    if (dist[tr][tc] == -1) return path;

    int r = tr, c = tc;
    while (!(r == sr && c == sc)) {
        path.push_back({r, c});
        auto p = parent[r][c];
        r = p.first;
        c = p.second;
    }
    reverse(path.begin(), path.end());
    return path;
}

void FindStartAndExit(const vector<string>& maze, int& playerR, int& playerC, int& exitR, int& exitC) {
    for (int r = 0; r < ROWS; r++) {
        for (int c = 0; c < COLS; c++) {
            if (maze[r][c] == 'S') {
                playerR = r;
                playerC = c;
            }
            if (maze[r][c] == 'E') {
                exitR = r;
                exitC = c;
            }
        }
    }
}

void AddRandomItems(const vector<string>& maze, vector<Item>& items, int playerR, int playerC, int exitR, int exitC, int enemyR, int enemyC) {
    items.clear();

    while ((int)items.size() < 5) {
        int r = GetRandomValue(1, ROWS - 2);
        int c = GetRandomValue(1, COLS - 2);

        if (!CanMove(maze, r, c)) continue;
        if (r == playerR && c == playerC) continue;
        if (r == exitR && c == exitC) continue;
        if (r == enemyR && c == enemyC) continue;

        bool duplicated = false;
        for (const auto& item : items) {
            if (item.r == r && item.c == c) duplicated = true;
        }
        if (!duplicated) items.push_back({r, c, false});
    }
}

void ResetGame(vector<string>& maze, int& playerR, int& playerC, int& exitR, int& exitC,
               Enemy& enemy, vector<Item>& items, int& score, int& currentMap,
               bool& win, bool& gameOver, float& enemyDelay) {
    currentMap = GetRandomValue(0, (int)mazeList.size() - 1);
    maze = mazeList[currentMap];

    FindStartAndExit(maze, playerR, playerC, exitR, exitC);

    enemy.r = exitR;
    enemy.c = exitC - 2;
    enemy.timer = 0.0f;

    score = 0;
    AddRandomItems(maze, items, playerR, playerC, exitR, exitC, enemy.r, enemy.c);

    win = false;
    gameOver = false;
    enemyDelay = 0.22f;
}

void CheckCollectItem(vector<Item>& items, int playerR, int playerC, int& score) {
    for (auto& item : items) {
        if (!item.collected && item.r == playerR && item.c == playerC) {
            item.collected = true;
            score += 10;
        }
    }
}

Color GetPlayerMainColor(int colorChoice) {
    // 0: vang, 1: tim, 2: hong, 3: den
    if (colorChoice == 0) return YELLOW;
    if (colorChoice == 1) return PURPLE;
    if (colorChoice == 2) return PINK;
    if (colorChoice == 3) return BLACK;
    return YELLOW;
}

Color GetPlayerBodyColor(int colorChoice) {
    // Mau phu cua than nhan vat de nhin ro hon
    if (colorChoice == 0) return GOLD;
    if (colorChoice == 1) return VIOLET;
    if (colorChoice == 2) return MAGENTA;
    if (colorChoice == 3) return DARKGRAY;
    return GOLD;
}

const char* GetPlayerColorName(int colorChoice) {
    if (colorChoice == 0) return "YELLOW";
    if (colorChoice == 1) return "PURPLE";
    if (colorChoice == 2) return "PINK";
    if (colorChoice == 3) return "BLACK";
    return "YELLOW";
}

void DrawPlayerPixelPreview(int x, int y, Color mainColor, Color bodyColor) {
    DrawRectangle(x + 18, y + 8, 36, 24, mainColor);
    DrawRectangle(x + 26, y + 16, 8, 8, WHITE);
    DrawRectangle(x + 40, y + 16, 8, 8, WHITE);
    DrawRectangle(x + 12, y + 36, 48, 30, bodyColor);
    DrawRectangle(x + 0, y + 42, 14, 24, mainColor);
    DrawRectangle(x + 58, y + 42, 14, 24, mainColor);
    DrawRectangle(x + 20, y + 66, 14, 16, BLACK);
    DrawRectangle(x + 40, y + 66, 14, 16, BLACK);
}

void DrawMainMenu(int colorChoice) {
    ClearBackground(Color{25, 28, 40, 255});

    DrawText("MAZE RUNNER", SCREEN_W / 2 - 170, 90, 46, WHITE);
    DrawText("MAIN MENU", SCREEN_W / 2 - 85, 145, 28, YELLOW);

    DrawText("CHON MAU NHAN VAT", SCREEN_W / 2 - 145, 220, 26, LIGHTGRAY);
    DrawText("Nhan LEFT / RIGHT de doi mau", SCREEN_W / 2 - 175, 260, 20, GRAY);
    DrawText("Nhan ENTER de bat dau", SCREEN_W / 2 - 135, 290, 20, GRAY);

    DrawText(TextFormat("<  %s  >", GetPlayerColorName(colorChoice)), SCREEN_W / 2 - 85, 345, 28, YELLOW);

    Color mainColor = GetPlayerMainColor(colorChoice);
    Color bodyColor = GetPlayerBodyColor(colorChoice);
    DrawPlayerPixelPreview(SCREEN_W / 2 - 36, 390, mainColor, bodyColor);

    DrawText("WASD / Arrow: di chuyen", SCREEN_W / 2 - 130, 505, 20, LIGHTGRAY);
    DrawText("R: restart random map    M: quay ve menu", SCREEN_W / 2 - 190, 535, 20, LIGHTGRAY);
}

void DrawPlayerPixel(int r, int c, Color mainColor, Color bodyColor) {
    int x = c * TILE;
    int y = r * TILE + UI_HEIGHT;

    DrawRectangle(x + 8, y + 3, 12, 8, mainColor);
    DrawRectangle(x + 10, y + 6, 3, 3, WHITE);
    DrawRectangle(x + 16, y + 6, 3, 3, WHITE);
    DrawRectangle(x + 6, y + 12, 16, 10, bodyColor);
    DrawRectangle(x + 3, y + 14, 5, 8, mainColor);
    DrawRectangle(x + 20, y + 14, 5, 8, mainColor);
    DrawRectangle(x + 8, y + 22, 5, 5, BLACK);
    DrawRectangle(x + 15, y + 22, 5, 5, BLACK);
}

void DrawEnemyPixel(int r, int c) {
    int x = c * TILE;
    int y = r * TILE + UI_HEIGHT;

    DrawRectangle(x + 6, y + 4, 16, 10, RED);
    DrawRectangle(x + 5, y + 14, 18, 10, MAROON);
    DrawRectangle(x + 8, y + 7, 4, 4, WHITE);
    DrawRectangle(x + 16, y + 7, 4, 4, WHITE);
    DrawRectangle(x + 9, y + 8, 2, 2, BLACK);
    DrawRectangle(x + 17, y + 8, 2, 2, BLACK);
    DrawRectangle(x + 3, y + 16, 5, 5, RED);
    DrawRectangle(x + 20, y + 16, 5, 5, RED);
}

void DrawItemPixel(int r, int c) {
    int x = c * TILE;
    int y = r * TILE + UI_HEIGHT;

    DrawRectangle(x + 11, y + 6, 6, 16, GOLD);
    DrawRectangle(x + 8, y + 9, 12, 10, ORANGE);
    DrawRectangleLines(x + 8, y + 9, 12, 10, BROWN);
}

int main() {
    InitWindow(SCREEN_W, SCREEN_H, "Maze Runner V3 - Menu Color Yellow Purple Pink Black");
    SetTargetFPS(60);

    vector<string> maze;
    int playerR, playerC, exitR, exitC;
    Enemy enemy;
    vector<Item> items;
    int score;
    int currentMap;
    bool win, gameOver;
    float enemyDelay;
    bool inMenu = true;
    int colorChoice = 0;

    ResetGame(maze, playerR, playerC, exitR, exitC, enemy, items, score, currentMap, win, gameOver, enemyDelay);

    while (!WindowShouldClose()) {
        if (inMenu) {
            if (IsKeyPressed(KEY_LEFT) || IsKeyPressed(KEY_A)) {
                colorChoice--;
                if (colorChoice < 0) colorChoice = 3;
            }
            if (IsKeyPressed(KEY_RIGHT) || IsKeyPressed(KEY_D)) {
                colorChoice++;
                if (colorChoice > 3) colorChoice = 0;
            }
            if (IsKeyPressed(KEY_ENTER)) {
                ResetGame(maze, playerR, playerC, exitR, exitC, enemy, items, score, currentMap, win, gameOver, enemyDelay);
                inMenu = false;
            }

            BeginDrawing();
            DrawMainMenu(colorChoice);
            EndDrawing();
            continue;
        }

        if (IsKeyPressed(KEY_M)) {
            inMenu = true;
        }

        if (IsKeyPressed(KEY_R)) {
            ResetGame(maze, playerR, playerC, exitR, exitC, enemy, items, score, currentMap, win, gameOver, enemyDelay);
        }

        if (!win && !gameOver) {
            int nr = playerR;
            int nc = playerC;

            if (IsKeyPressed(KEY_W) || IsKeyPressed(KEY_UP)) nr--;
            if (IsKeyPressed(KEY_S) || IsKeyPressed(KEY_DOWN)) nr++;
            if (IsKeyPressed(KEY_A) || IsKeyPressed(KEY_LEFT)) nc--;
            if (IsKeyPressed(KEY_D) || IsKeyPressed(KEY_RIGHT)) nc++;

            if (CanMove(maze, nr, nc)) {
                playerR = nr;
                playerC = nc;
                CheckCollectItem(items, playerR, playerC, score);
            }

            if (playerR == exitR && playerC == exitC) {
                win = true;
            }

            enemy.timer += GetFrameTime();
            if (enemy.timer >= enemyDelay) {
                enemy.timer = 0.0f;
                vector<pair<int,int>> path = FindPath(maze, enemy.r, enemy.c, playerR, playerC);
                if (!path.empty()) {
                    enemy.r = path[0].first;
                    enemy.c = path[0].second;
                }
            }

            if (enemy.r == playerR && enemy.c == playerC) {
                gameOver = true;
            }
        }

        BeginDrawing();
        ClearBackground(RAYWHITE);

        DrawRectangle(0, 0, SCREEN_W, UI_HEIGHT, Color{28, 32, 45, 255});
        DrawText("MAZE RUNNER V3", 20, 12, 26, WHITE);
        DrawText("WASD / Arrow: move   R: random restart   M: menu", 250, 18, 20, LIGHTGRAY);
        DrawText(TextFormat("Map: %d   Score: %d   Color: %s", currentMap + 1, score, GetPlayerColorName(colorChoice)), 250, 43, 20, YELLOW);

        if (win) DrawText("YOU WIN! Press R", SCREEN_W - 260, 20, 24, GREEN);
        if (gameOver) DrawText("GAME OVER! Press R", SCREEN_W - 300, 20, 24, RED);

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int x = c * TILE;
                int y = r * TILE + UI_HEIGHT;

                if (maze[r][c] == '#') {
                    DrawRectangle(x, y, TILE, TILE, DARKBLUE);
                    DrawRectangleLines(x, y, TILE, TILE, Color{10, 20, 60, 255});
                } else {
                    DrawRectangle(x, y, TILE, TILE, Color{235, 235, 235, 255});
                    DrawRectangleLines(x, y, TILE, TILE, Color{210, 210, 210, 255});
                }
            }
        }

        DrawRectangle(exitC * TILE + 4, exitR * TILE + UI_HEIGHT + 4, TILE - 8, TILE - 8, GREEN);
        DrawText("E", exitC * TILE + 8, exitR * TILE + UI_HEIGHT + 4, 22, WHITE);

        for (const auto& item : items) {
            if (!item.collected) DrawItemPixel(item.r, item.c);
        }

        DrawPlayerPixel(playerR, playerC, GetPlayerMainColor(colorChoice), GetPlayerBodyColor(colorChoice));
        DrawEnemyPixel(enemy.r, enemy.c);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}

#!/bin/bash
set -e

# Build portable Windows exe packages for Maze Runner versions using MSYS2 UCRT64.
# Run this file inside MSYS2 UCRT64, in the same folder as main.cpp, main_2.cpp, main_3.cpp.

CXX=g++
COMMON_FLAGS="-static-libgcc -static-libstdc++"
LIBS="-lraylib -lopengl32 -lgdi32 -lwinmm"
BIN_DIR="/ucrt64/bin"

copy_if_exists() {
    local src="$1"
    local dst="$2"
    if [ -f "$src" ]; then
        cp "$src" "$dst/"
    fi
}

make_package() {
    local src_cpp="$1"
    local exe_name="$2"
    local out_dir="$3"
    local zip_name="$4"

    echo "========================================"
    echo "Building $src_cpp -> $exe_name"
    echo "========================================"

    $CXX "$src_cpp" -o "$exe_name" $COMMON_FLAGS $LIBS

    rm -rf "$out_dir"
    mkdir -p "$out_dir"
    cp "$exe_name" "$out_dir/"

    # DLLs usually needed when raylib is installed from MSYS2 UCRT64.
    copy_if_exists "$BIN_DIR/raylib.dll" "$out_dir"
    copy_if_exists "$BIN_DIR/libwinpthread-1.dll" "$out_dir"
    copy_if_exists "$BIN_DIR/libstdc++-6.dll" "$out_dir"
    copy_if_exists "$BIN_DIR/libgcc_s_seh-1.dll" "$out_dir"

    cat > "$out_dir/README_CHAY_GAME.txt" <<TXT
Giai nen folder nay roi bam file:
$exe_name

Neu Windows bao thieu DLL, hay bao lai nguoi build game de copy them DLL bi thieu tu C:\\msys64\\ucrt64\\bin.
TXT

    rm -f "$zip_name"
    zip -r "$zip_name" "$out_dir" >/dev/null
    echo "Created $zip_name"
}

make_package "main.cpp"   "maze_runner_v1.exe" "portable_v1_main" "portable_v1_main.zip"
make_package "main_2.cpp" "maze_runner_v2.exe" "portable_v2_main_2" "portable_v2_main_2.zip"
make_package "main_3.cpp" "maze_runner_v3.exe" "portable_v3_main_3" "portable_v3_main_3.zip"

rm -rf portable_all_versions
mkdir -p portable_all_versions
cp -r portable_v1_main portable_all_versions/
cp -r portable_v2_main_2 portable_all_versions/
cp -r portable_v3_main_3 portable_all_versions/
cat > portable_all_versions/README_CHON_BAN.txt <<TXT
Co 3 ban game:

1. portable_v1_main/maze_runner_v1.exe
   Ban goc.

2. portable_v2_main_2/maze_runner_v2.exe
   Ban them nhan vat pixel va vat pham.

3. portable_v3_main_3/maze_runner_v3.exe
   Ban hoan chinh: pixel, vat pham, random map, menu mau nhan vat.

Nguoi nhan chi can giai nen zip va bam file .exe trong tung folder.
TXT
rm -f portable_all_versions.zip
zip -r portable_all_versions.zip portable_all_versions >/dev/null

echo "========================================"
echo "Done. Send these zip files to other people:"
echo "- portable_v1_main.zip"
echo "- portable_v2_main_2.zip"
echo "- portable_v3_main_3.zip"
echo "- portable_all_versions.zip"
echo "========================================"

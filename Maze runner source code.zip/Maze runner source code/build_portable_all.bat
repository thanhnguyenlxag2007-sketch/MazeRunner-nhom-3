@echo off
REM Build portable Windows exe packages for Maze Runner versions.
REM Run this from normal Windows CMD/PowerShell only if C:\msys64\ucrt64\bin is in PATH.
REM If not, use build_portable_all.sh inside MSYS2 UCRT64 instead.

set BIN=C:\msys64\ucrt64\bin
set CXX=g++
set FLAGS=-static-libgcc -static-libstdc++
set LIBS=-lraylib -lopengl32 -lgdi32 -lwinmm

call :build main.cpp maze_runner_v1.exe portable_v1_main
if errorlevel 1 goto fail
call :build main_2.cpp maze_runner_v2.exe portable_v2_main_2
if errorlevel 1 goto fail
call :build main_3.cpp maze_runner_v3.exe portable_v3_main_3
if errorlevel 1 goto fail

echo.
echo Xong. Hay gui cac folder portable_v1_main, portable_v2_main_2, portable_v3_main_3 cho nguoi khac.
pause
exit /b 0

:build
echo ========================================
echo Building %1 -^> %2
echo ========================================
%CXX% %1 -o %2 %FLAGS% %LIBS%
if errorlevel 1 exit /b 1
if exist %3 rmdir /s /q %3
mkdir %3
copy %2 %3\ >nul
if exist "%BIN%\raylib.dll" copy "%BIN%\raylib.dll" %3\ >nul
if exist "%BIN%\libwinpthread-1.dll" copy "%BIN%\libwinpthread-1.dll" %3\ >nul
if exist "%BIN%\libstdc++-6.dll" copy "%BIN%\libstdc++-6.dll" %3\ >nul
if exist "%BIN%\libgcc_s_seh-1.dll" copy "%BIN%\libgcc_s_seh-1.dll" %3\ >nul
echo Giai nen folder nay va bam file %2 de chay. > %3\README_CHAY_GAME.txt
exit /b 0

:fail
echo Build bi loi. Nen mo MSYS2 UCRT64 va chay: ./build_portable_all.sh
pause
exit /b 1

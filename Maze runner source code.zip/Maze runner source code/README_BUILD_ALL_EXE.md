# Build 3 bản Maze Runner thành file EXE portable

Dùng trên máy đã cài MSYS2 UCRT64 + raylib.

## Cách chạy khuyên dùng

Mở **MSYS2 UCRT64** trong thư mục này rồi chạy:

```bash
chmod +x build_portable_all.sh
./build_portable_all.sh
```

Sau khi chạy xong sẽ có:

```text
portable_v1_main.zip
portable_v2_main_2.zip
portable_v3_main_3.zip
portable_all_versions.zip
```

Gửi file zip cho bạn bè. Người nhận chỉ cần giải nén và bấm `.exe`, không cần cài raylib.

## Ý nghĩa 3 bản

- `main.cpp` → `maze_runner_v1.exe`: bản gốc.
- `main_2.cpp` → `maze_runner_v2.exe`: thêm nhân vật pixel và vật phẩm.
- `main_3.cpp` → `maze_runner_v3.exe`: bản hoàn chỉnh có random map và menu chọn màu nhân vật.

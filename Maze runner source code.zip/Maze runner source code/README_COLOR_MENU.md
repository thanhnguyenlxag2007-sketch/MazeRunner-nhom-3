# Maze Runner main_3.cpp - Menu chon mau nhan vat

File quan trong: `main_3.cpp`

Ban nay duoc sua tu main 3, them menu chinh cho phep chon mau nhan vat:

- Yellow
- Purple
- Pink
- Black

## Dieu khien menu

- A / mui ten trai: doi mau sang trai
- D / mui ten phai: doi mau sang phai
- Enter: bat dau game

## Dieu khien trong game

- WASD / Arrow: di chuyen
- R: restart va random map moi
- M: quay ve menu chon mau

## Compile

```bash
g++ main_3.cpp -o maze_runner_v3.exe -lraylib -lopengl32 -lgdi32 -lwinmm
./maze_runner_v3.exe
```

Hoac chay nhanh trong MSYS2 UCRT64:

```bash
chmod +x run_main_3.sh
./run_main_3.sh
```

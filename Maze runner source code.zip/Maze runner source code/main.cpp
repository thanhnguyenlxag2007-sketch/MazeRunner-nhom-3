#include "raylib.h"
#include <vector>
#include <queue>
#include <random>
#include <ctime>
#include <algorithm>
#include <string>

using namespace std;

const int ROWS = 21;
const int COLS = 31;
const int TILE = 28;
const int UI_HEIGHT = 70;
const int SCREEN_W = COLS * TILE;
const int SCREEN_H = ROWS * TILE + UI_HEIGHT;

struct Enemy {
    int r, c;
    float timer;
};

vector<string> baseMaze = {
    "###############################",
    "#S#.........#.................#",
    "#.#.#######.#.#############.#.#",
    "#.#.....#...#.....#.......#.#.#",
    "#.#####.#.#######.#.#####.#.#.#",
    "#.....#.#.......#.#.#...#.#.#.#",
    "#####.#.#######.#.#.#.#.#.#.#.#",
    "#.....#.....#...#...#.#...#...#",
    "#.#########.#.#######.#######.#",
    "#.........#.#.....#.........#.#",
    "#.#######.#.#####.#.#######.#.#",
    "#.#.....#.#.....#.#.#.....#.#.#",
    "#.#.###.#.#####.#.#.#.###.#.#.#",
    "#.#...#.#.......#.#...#...#...#",
    "#.###.#.#########.#####.#####.#",
    "#.....#.........#.....#.....#.#",
    "#.#############.#.###.#####.#.#",
    "#...............#...#.......#.#",
    "#.#################.#########.#",
    "#.........................E...#",
    "###############################"
};

bool IsWall(const vector<string>& maze, int r, int c) {
    if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return true;
    return maze[r][c] == '#';
}

bool CanMove(const vector<string>& maze, int r, int c) {
    return !IsWall(maze, r, c);
}

vector<pair<int,int>> FindPath(const vector<string>& maze, int sr, int sc, int tr, int tc) {
    vector<vector<int>> dist(ROWS, vector<int>(COLS, -1));
    vector<vector<pair<int,int>>> parent(ROWS, vector<pair<int,int>>(COLS, {-1, -1}));
    queue<pair<int,int>> q;
    q.push({sr, sc});
    dist[sr][sc] = 0;

    int dr[4] = {-1, 1, 0, 0};
    int dc[4] = {0, 0, -1, 1};

    while (!q.empty()) {
        auto [r, c] = q.front();
        q.pop();

        if (r == tr && c == tc) break;

        for (int i = 0; i < 4; i++) {
            int nr = r + dr[i];
            int nc = c + dc[i];
            if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && dist[nr][nc] == -1 && CanMove(maze, nr, nc)) {
                dist[nr][nc] = dist[r][c] + 1;
                parent[nr][nc] = {r, c};
                q.push({nr, nc});
            }
        }
    }

    vector<pair<int,int>> path;
    if (dist[tr][tc] == -1) return path;

    int r = tr, c = tc;
    while (!(r == sr && c == sc)) {
        path.push_back({r, c});
        auto p = parent[r][c];
        r = p.first;
        c = p.second;
    }
    reverse(path.begin(), path.end());
    return path;
}

void ResetGame(vector<string>& maze, int& playerR, int& playerC, int& exitR, int& exitC, Enemy& enemy, bool& win, bool& gameOver, float& enemyDelay) {
    maze = baseMaze;
    playerR = 1;
    playerC = 1;
    exitR = 19;
    exitC = 29;
    enemy.r = 19;
    enemy.c = 27;
    enemy.timer = 0.0f;
    win = false;
    gameOver = false;
    enemyDelay = 0.22f;
}

int main() {
    InitWindow(SCREEN_W, SCREEN_H, "Maze Runner - raylib C++");
    SetTargetFPS(60);

    vector<string> maze;
    int playerR, playerC, exitR, exitC;
    Enemy enemy;
    bool win, gameOver;
    float enemyDelay;

    ResetGame(maze, playerR, playerC, exitR, exitC, enemy, win, gameOver, enemyDelay);

    while (!WindowShouldClose()) {
        if (IsKeyPressed(KEY_R)) {
            ResetGame(maze, playerR, playerC, exitR, exitC, enemy, win, gameOver, enemyDelay);
        }

        if (!win && !gameOver) {
            int nr = playerR;
            int nc = playerC;

            if (IsKeyPressed(KEY_W) || IsKeyPressed(KEY_UP)) nr--;
            if (IsKeyPressed(KEY_S) || IsKeyPressed(KEY_DOWN)) nr++;
            if (IsKeyPressed(KEY_A) || IsKeyPressed(KEY_LEFT)) nc--;
            if (IsKeyPressed(KEY_D) || IsKeyPressed(KEY_RIGHT)) nc++;

            if (CanMove(maze, nr, nc)) {
                playerR = nr;
                playerC = nc;
            }

            if (playerR == exitR && playerC == exitC) {
                win = true;
            }

            enemy.timer += GetFrameTime();
            if (enemy.timer >= enemyDelay) {
                enemy.timer = 0.0f;
                vector<pair<int,int>> path = FindPath(maze, enemy.r, enemy.c, playerR, playerC);
                if (!path.empty()) {
                    enemy.r = path[0].first;
                    enemy.c = path[0].second;
                }
            }

            if (enemy.r == playerR && enemy.c == playerC) {
                gameOver = true;
            }
        }

        BeginDrawing();
        ClearBackground(RAYWHITE);

        DrawRectangle(0, 0, SCREEN_W, UI_HEIGHT, Color{28, 32, 45, 255});
        DrawText("MAZE RUNNER", 20, 16, 28, WHITE);
        DrawText("WASD / Arrow: move   R: restart", 250, 25, 20, LIGHTGRAY);

        if (win) DrawText("YOU WIN! Press R", SCREEN_W - 260, 20, 24, GREEN);
        if (gameOver) DrawText("GAME OVER! Press R", SCREEN_W - 300, 20, 24, RED);

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int x = c * TILE;
                int y = r * TILE + UI_HEIGHT;

                if (maze[r][c] == '#') {
                    DrawRectangle(x, y, TILE, TILE, DARKBLUE);
                    DrawRectangleLines(x, y, TILE, TILE, Color{10, 20, 60, 255});
                } else {
                    DrawRectangle(x, y, TILE, TILE, Color{235, 235, 235, 255});
                    DrawRectangleLines(x, y, TILE, TILE, Color{210, 210, 210, 255});
                }
            }
        }

        DrawRectangle(exitC * TILE + 4, exitR * TILE + UI_HEIGHT + 4, TILE - 8, TILE - 8, GREEN);
        DrawText("E", exitC * TILE + 8, exitR * TILE + UI_HEIGHT + 4, 22, WHITE);

        DrawCircle(playerC * TILE + TILE / 2, playerR * TILE + UI_HEIGHT + TILE / 2, TILE / 2 - 5, BLUE);
        DrawCircle(enemy.c * TILE + TILE / 2, enemy.r * TILE + UI_HEIGHT + TILE / 2, TILE / 2 - 5, RED);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
